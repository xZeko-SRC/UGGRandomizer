﻿using System;
using MelonLoader;
using UnityEngine;
using UnityEngine.SceneManagement;
using Random = System.Random;

namespace UGGRandomizer
{
    public class RandomMain : MelonMod
    {
        private string seedText = "0";  // Default seed input as a string
        private int seed;           // Default seed value
        private bool showSeedInput = true;  // Control whether the seed input is shown
        private bool seedEntered = false;   // Track whether a seed has been entered
        private bool showWarning = false; // Flag to show warning
        private string warningMessage = ""; // Stores the warning message
        private bool showSeed = false; // Flag to control seed visibility

        public override void OnGUI()
        {
            //if (SceneManager.GetActiveScene().name == "base" && showSeedInput)
            if (showSeedInput)
            {
                // Display the input field for the seed
                //GUILayout.BeginArea(new Rect(10, 10, 200, 150));  // Define the input area
                GUILayout.BeginArea(new Rect(10, 10, 200, 150));  // Define the input area
                GUILayout.Label("Enter Seed:");
                seedText = GUILayout.TextField(seedText, 9);  // Display a text field for seed input
                //MelonLogger.Msg("Enter Seed:");
                if (GUILayout.Button("Submit Seed"))
                {
                    OnSeedInputChanged();
                    MelonLogger.Msg("Seed Submitted: :)");
                }
                if (showWarning)
                {
                    GUIStyle warningStyle = new GUIStyle();
                    warningStyle.normal.textColor = Color.red; // Set text color to red
                    GUILayout.Label(warningMessage, warningStyle); // Display the warning
                }
                GUILayout.EndArea();
                GUILayout.BeginArea(new Rect(10, 220, 300, 100)); // Adjust the rectangle for the show seed section
                if (showSeed)
                {
                    GUILayout.Label("Generated Seed: " + seed);
                }
                GUILayout.EndArea();
            }
        }

        public override void OnUpdate()
        {
            if (Input.GetKeyDown(KeyCode.Alpha2))
            {
                //ShuffleItems(seed);
                showSeedInput = true;
            }
            if (Input.GetKeyDown(KeyCode.Alpha3))
            {
                //ShuffleItems(seed);
                showSeed = !showSeed;
            }
        }

        public void OnSeedInputChanged()
        {
            // Get the inputted seed from the TextField and convert it to an integer
            if (int.TryParse(seedText, out seed))
            {
                if (seed == 0)
                {
                    seed = new System.Random().Next(1, int.MaxValue);  // Generate a random seed
                    MelonLogger.Msg("Generated random seed: " + seed);
                }
                    seedEntered = true;
                    showSeedInput = false;  // Hide the seed input UI once the seed is submitted
                    showWarning = false; // Reset the warning
                    ShuffleItems(seed);  // Use the seed to shuffle
                    MelonLogger.Msg("Shuffled with seed: " + seed);
            }
            else
            {
                warningMessage = "Invalid seed input.\nPlease enter a number.";
                showWarning = true;
                MelonLogger.Msg("Invalid seed input.");
            }
        }

        public override void OnSceneWasInitialized(int buildIndex, string sceneName)
        {
            // Check if the build index is 2
            if (buildIndex == 2) // Assuming buildIndex 2 is for the "main" scene
            {
                showSeedInput = true; // Show seed input when main scene is loaded
                MelonLogger.Msg("Scene Initialized: " + sceneName);
            }
            else
            {
                showSeedInput = false; // Optionally hide it for other scenes
            }

            // Log the build index and scene name for debugging
            MelonLogger.Msg("OnSceneWasInitialized: " + buildIndex.ToString() + " | " + sceneName);
        }

        public Transform[] itemTransforms;  // Attach item transforms from the Unity editor
        public Vector3[] positions;         // Define all possible positions in the Unity editor
        public static void ShuffleItems(int seed)
        {
            MelonLogger.Msg("Shuffling items deterministically with seed: " + seed);

            // Initialize a random generator with the seed for determinism
            System.Random rand = new System.Random(seed);

            for (int i = Constants.allitems.Length - 1; i > 0; i--)
            {
                // Use the random generator to get a safe index within bounds
                int j = rand.Next(0, i + 1);

                // Swap elements in the array deterministically
                string temp = Constants.allitems[i];
                Constants.allitems[i] = Constants.allitems[j];
                Constants.allitems[j] = temp;

                // Move GameObjects to new positions deterministically
                GameObject spawnItem = GameObject.Find(Constants.allitems[i]);
                GameObject spawnItem1 = GameObject.Find(Constants.allitems[j]);

                if (spawnItem != null && spawnItem1 != null)  // Check if the GameObjects exist
                {
                    // Swap positions of the GameObjects
                    Vector3 tempPosition = spawnItem.transform.position;
                    spawnItem.transform.position = spawnItem1.transform.position;
                    spawnItem1.transform.position = tempPosition;

                    MelonLogger.Msg($"Swapped positions: {Constants.allitems[i]} <-> {Constants.allitems[j]}");
                }
                else
                {
                    MelonLogger.Error($"GameObject not found for items: {Constants.allitems[i]} or {Constants.allitems[j]}");
                }
            }
        }
    }
}
