﻿using System;
using MelonLoader;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using Random = System.Random;

namespace UGGRandomizer
{
    public class RandomMain : MelonMod
    {
        private string seedText = "0";  // Default seed input as a string
        private int seed;           // Default seed value
        private bool showSeedInput = true;  // Control whether the seed input is shown
        private bool seedEntered = false;   // Track whether a seed has been entered
        private bool showWarning = false; // Flag to show warning
        private string warningMessage = ""; // Stores the warning message
        private bool showSeed = false; // Flag to control seed visibility
        private bool showHowTo = false; // Flag to show the how to

        public override void OnGUI()
        {
            // Show seed input if enabled
            if (showSeedInput)
            {
                GUILayout.BeginArea(new Rect(10, 10, 200, 150));  // Define the input area
                GUILayout.Label("Enter Seed:");
                seedText = GUILayout.TextField(seedText, 9);  // Display a text field for seed input

                if (GUILayout.Button("Submit Seed"))
                {
                    OnSeedInputChanged();
                    MelonLogger.Msg("Seed Submitted: :)");
                }

                if (showWarning)
                {
                    GUIStyle warningStyle = new GUIStyle();
                    warningStyle.normal.textColor = Color.red; // Set text color to red
                    GUILayout.Label(warningMessage, warningStyle); // Display the warning
                }

                GUILayout.EndArea(); // End the seed input area
            }

            // Show generated seed if the button has been pressed
            if (showSeed)
            {
                GUILayout.BeginArea(new Rect(10, 220, 300, 100)); // Adjust the rectangle for the show seed section
                GUILayout.Label("Generated Seed: " + seed);
                GUILayout.EndArea(); // End the generated seed area
            }

            // Show "How To" instructions if enabled
            if (showHowTo)
            {
                GUILayout.BeginArea(new Rect(15, 300, 350, 450)); // Adjust the rectangle for the how-to section
                GUILayout.Label("------------------------------------------------------");
                GUILayout.Label("Welcome to UGG Item Randomizer!");
                GUILayout.Label("------------------------------------------------------");
                GUILayout.Label("How To:");
                GUILayout.Label("Start the game normally, choosing either the yellow, green, or red book. (Make sure you erase the save if starting from the beginning)");
                GUILayout.Label("Load into the game, and before you honk, you will notice the input seed box has appeared.");
                GUILayout.Label("Input any desired number for a seed. If 0 is inputted, a random seed will be generated.");
                GUILayout.Label("(Only numbers can be inputted. Letters will not work)");
                GUILayout.Label("Select the input seed button after you have chosen your number. You can now honk and play!");
                GUILayout.Label("Enjoy!");
                GUILayout.Label("You can quit and reload anytime and it will save normally.");
                GUILayout.Label("You will have to erase the saved book for the items to go back to normal.");
                GUILayout.Label("------------------------------------------------------");
                GUILayout.Label("Made by xZeKo");
                GUILayout.EndArea(); // End the How To area
            }
        }

        private Text uiText; // UI Text component
        private Color[] rainbowColors = new Color[]
        {
        Color.red,
        Color.yellow,
        Color.green,
        Color.cyan,
        Color.blue,
        Color.magenta
        };
        private float timeCounter;
        private GameObject textObject; // Store the reference for cleanup or updates
        private bool uiInitialized = false;

        public override void OnUpdate()
        {
            if (Input.GetKeyDown(KeyCode.Alpha2))
            {
                //ShuffleItems(seed);
                showSeedInput = true;
            }
            if (Input.GetKeyDown(KeyCode.Alpha3))
            {
                //ShuffleItems(seed);
                showSeed = !showSeed;
            }
            // Initialize UI only once
            //if (!uiInitialized)
            //{
                //InitializeUI();
                //uiInitialized = true;
            //}

            // Update color over time
            if (uiText != null)
            {
                timeCounter += Time.deltaTime;
                float lerpTime = Mathf.PingPong(timeCounter, 1f);
                int colorIndex1 = Mathf.FloorToInt(lerpTime * (rainbowColors.Length - 1));
                int colorIndex2 = Mathf.CeilToInt(lerpTime * (rainbowColors.Length - 1));
                uiText.color = Color.Lerp(rainbowColors[colorIndex1], rainbowColors[colorIndex2], lerpTime);
            }
        }

        public void OnSeedInputChanged()
        {
            // Get the inputted seed from the TextField and convert it to an integer
            if (int.TryParse(seedText, out seed))
            {
                if (seed == 0)
                {
                    seed = new System.Random().Next(1, int.MaxValue);  // Generate a random seed
                    MelonLogger.Msg("Generated random seed: " + seed);

                }
                    seedEntered = true;
                    showSeedInput = false;  // Hide the seed input UI once the seed is submitted
                    showWarning = false; // Reset the warning
                    ShuffleItems(seed);  // Use the seed to shuffle
                    MelonLogger.Msg("Shuffled with seed: " + seed);
            }
            else
            {
                warningMessage = "Invalid seed input.\nPlease enter a number.";
                showWarning = true;
                MelonLogger.Msg("Invalid seed input.");
            }
        }

        public override void OnSceneWasLoaded(int buildIndex, string sceneName)
        {
            if (buildIndex == 1)
            {
                showHowTo = true;
                // If the UI was previously destroyed or never initialized, re-initialize it
                if (!uiInitialized || textObject == null)
                {
                    InitializeUI();
                }

                uiInitialized = true;
                MelonLogger.Msg("Scene Initialized: " + sceneName);
            }
            // Check if the build index is 2
            if (buildIndex == 2) // Assuming buildIndex 2 is for the "main" scene
            {
                showSeedInput = true; // Show seed input when main scene is loaded
                showHowTo = false;
                // Destroy the canvas and its contents
                if (textObject != null)
                {
                    GameObject.Destroy(textObject);
                    MelonLogger.Msg("UI Canvas Destroyed for scene: " + sceneName);
                }

                uiInitialized = false;  // Mark UI as uninitialized
                MelonLogger.Msg("Scene Initialized: " + sceneName);
                MelonLogger.Msg("Scene Initialized: " + sceneName);
            }
            else
            {
                showSeedInput = false; // Optionally hide it for other scenes
            }

            // Log the build index and scene name for debugging
            MelonLogger.Msg("OnSceneWasInitialized: " + buildIndex.ToString() + " | " + sceneName);
        }
        private void InitializeUI()
        {
            MelonLogger.Msg("Initializing UI...");
            if (uiInitialized && textObject != null) return;

            // Create a Canvas
            GameObject canvasObject = new GameObject("Canvas");
            Canvas canvas = canvasObject.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay; // Ensure it's in Overlay mode

            // Set Canvas Sorting Order to ensure it's on top
            canvas.sortingOrder = 1000;

            // Set the Canvas as active and visible
            canvasObject.AddComponent<CanvasScaler>();
            canvasObject.AddComponent<GraphicRaycaster>();
            canvasObject.SetActive(true);

            // Create a new Text object
            textObject = new GameObject("RainbowText");
            uiText = textObject.AddComponent<Text>();
            uiText.text = "Item\nRandomizer";
            uiText.font = Resources.GetBuiltinResource<Font>("Arial.ttf"); // Use built-in Arial font
            uiText.fontSize = 75; // Font size reduced for testing, can be adjusted
            uiText.alignment = TextAnchor.MiddleCenter;
            uiText.horizontalOverflow = HorizontalWrapMode.Overflow; // Prevent text from clipping horizontally
            uiText.verticalOverflow = VerticalWrapMode.Overflow;     // Prevent vertical clipping

            textObject.SetActive(true);

            // Set text position at the top center of the screen
            RectTransform rectTransform = textObject.GetComponent<RectTransform>();
            rectTransform.SetParent(canvas.transform);

            // Ensure the RectTransform has the correct anchors and position
            rectTransform.anchorMin = new Vector2(0.5f, 1f); // Anchor to the top center
            rectTransform.anchorMax = new Vector2(0.5f, 1f); // Anchor to the top center
            rectTransform.pivot = new Vector2(0.5f, 1f);     // Pivot aligned at the top center
            rectTransform.anchoredPosition = new Vector2(0, -30); // Adjust Y position to avoid it being too high

            // Explicitly set the size of the RectTransform to allow full text rendering
            rectTransform.sizeDelta = new Vector2(500, 200); // Adjust width and height as needed to fit the text

            // Set proper scale
            rectTransform.localScale = Vector3.one;

            // Set initial text color
            uiText.color = Color.white;

            MelonLogger.Msg("UI Initialized");
        }

        public Transform[] itemTransforms;  // Attach item transforms from the Unity editor
        public Vector3[] positions;         // Define all possible positions in the Unity editor
        public static void ShuffleItems(int seed)
        {
            MelonLogger.Msg("Shuffling items deterministically with seed: " + seed);

            // Initialize a random generator with the seed for determinism
            System.Random rand = new System.Random(seed);

            for (int i = Constants.allitems.Length - 1; i > 0; i--)
            {
                // Use the random generator to get a safe index within bounds
                int j = rand.Next(0, i + 1);

                // Swap elements in the array deterministically
                string temp = Constants.allitems[i];
                Constants.allitems[i] = Constants.allitems[j];
                Constants.allitems[j] = temp;

                // Move GameObjects to new positions deterministically
                GameObject spawnItem = GameObject.Find(Constants.allitems[i]);
                GameObject spawnItem1 = GameObject.Find(Constants.allitems[j]);

                if (spawnItem != null && spawnItem1 != null)  // Check if the GameObjects exist
                {
                    // Swap positions of the GameObjects
                    Vector3 tempPosition = spawnItem.transform.position;
                    spawnItem.transform.position = spawnItem1.transform.position;
                    spawnItem1.transform.position = tempPosition;

                    MelonLogger.Msg($"Swapped positions: {Constants.allitems[i]} <-> {Constants.allitems[j]}");
                }
                else
                {
                    MelonLogger.Error($"GameObject not found for items: {Constants.allitems[i]} or {Constants.allitems[j]}");
                }
            }
        }
    }
}
